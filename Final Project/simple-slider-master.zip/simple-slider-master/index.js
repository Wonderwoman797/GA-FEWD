module.exports = require('./dist/simpleslider')
